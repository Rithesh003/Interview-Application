<?php
require_once('dbconfig/config.php');
$sql = "SELECT * FROM user1";  
$result = mysqli_query($con, $sql);
?>
<html>  
 <head>  
 <style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
  <title>Candidate details from the Registration form</title>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
 </head>  
 <body>  
  <div class="container">  
   <br />  
   <br />  
   <br />  
   <form action="index.php" method="post">
			<div class="inner_container">
				<button style='color:black;border:round' class="btn btn-primary" type="submit">back</button>	
			</div>
		<!-- </form>
    <form action="dash1.php" method="post">
			<div class="inner_container">
				<button style='color:black;border:round' class="btn btn-primary" type="submit">candidate list</button>	
			</div>
		</form>
   <form action="dashboard.php" method="post">
			<div class="inner_container">
				<button style='color:black;font-size:20px;border:round' class="btn btn-danger" type="submit">Dashboard</button>	
			</div>
		</form>  -->
    <div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="dash1.php">Candidate List</a>
  <a href="dashboard.php">Dashboard</a>
  <a href="index.php">Logout</a>
</div>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776; open</span>

<!-- Use any element to open the sidenav -->


<!-- Add all page content inside this div if you want the side nav to push page content to the right (not used if you only want the sidenav to sit on top of the page -->

   <!-- <form method="post" action="export.php">
     <input type="submit" name="export" style='color:black;font-size:20px;border:round' class="btn btn-success" value="Export" />
    </form> -->
   <!-- <div class="table-responsive">  
    <h2 align="center">Candidate details from the Registration form</h2><br /> 
    <table class="table table-bordered">
	<tr> 
  <td> <font face="Arial"> ID</font> </td>
          <td> <font face="Arial"> First Name</font> </td>
          <td> <font face="Arial"> Last Name</font> </td>
          <td> <font face="Arial"> Email</font> </td> 
          <td> <font face="Arial"> Location</font> </td> 
          <td> <font face="Arial"> Mobile Number</font> </td>
		  <td> <font face="Arial"> Gender</font> </td> 
          <td> <font face="Arial"> Degree</font> </td> 
		  <td> <font face="Arial"> Department</font> </td> 
          <td> <font face="Arial">  Passout Year</font> </td>  
		  <td> <font face="Arial"> Programming Skills</font> </td> 
          <td> <font face="Arial"> Languages</font> </td> 
      </tr>
     <?php
     while($row = mysqli_fetch_array($result))  
     {  
        echo '  
       <tr>  
       <td>'.$row["id"].'</td>  
         <td>'.$row["FirstName"].'</td>  
         <td>'.$row["LastName"].'</td>  
         <td>'.$row["email"].'</td>  
         <td>'.$row["location"].'</td>  
         <td>'.$row["MobileNumber"].'</td>
		 <td>'.$row["Gender"].'</td>  
         <td>'.$row["degree"].'</td>
		 <td>'.$row["department"].'</td>  
         <td>'.$row["passoutyear"].'</td>
		 <td>'.$row["skills"].'</td>  
         <td>'.$row["languages"].'</td>
       </tr>  
        ';  
     }
     ?>
    </table>
    <br />
   </div>  
  </div>  -->
  <!-- <form action="index.php" method="post">
			<div class="inner_container">
				<button style='color:black;font-size:20px;border:round' class="btn btn-danger" type="submit">Log Out</button>	
			</div>
		</form>  -->
    <script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>
 </body>  
</html>