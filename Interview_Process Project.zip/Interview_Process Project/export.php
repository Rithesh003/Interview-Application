<?php  
require_once('dbconfig/config.php');
$output = '';
if(isset($_POST["export"]))
{
 $query = "SELECT * FROM user1";
 $result = mysqli_query($con, $query);
 if(mysqli_num_rows($result) > 0)
 {
  $output .= '
   <table class="table" bordered="1">  
   <tr> 
   <td> <font face="Arial"> First Name</font> </td>
   <td> <font face="Arial"> Last Name</font> </td>
   <td> <font face="Arial"> Email</font> </td> 
   <td> <font face="Arial"> Location</font> </td> 
   <td> <font face="Arial"> Mobile Number</font> </td>
   <td> <font face="Arial"> Gender</font> </td> 
   <td> <font face="Arial"> Degree</font> </td> 
   <td> <font face="Arial"> Department</font> </td> 
   <td> <font face="Arial">  Passout Year</font> </td>  
   <td> <font face="Arial"> Programming Skills</font> </td> 
   <td> <font face="Arial"> Languages</font> </td> 
</tr>
  ';
  while($row = mysqli_fetch_array($result))
  {
   $output .= '
   <tr>  
   <td>'.$row["FirstName"].'</td>  
   <td>'.$row["LastName"].'</td>  
   <td>'.$row["email"].'</td>  
   <td>'.$row["location"].'</td>  
   <td>'.$row["MobileNumber"].'</td>
   <td>'.$row["Gender"].'</td>  
   <td>'.$row["degree"].'</td>
   <td>'.$row["department"].'</td>  
   <td>'.$row["passoutyear"].'</td>
   <td>'.$row["skills"].'</td>  
   <td>'.$row["languages"].'</td>
 </tr>  
  ';  
  }
  $output .= '</table>';
  header('Content-Type: application/xls');
  header('Content-Disposition: attachment; filename=download.xls');
  echo $output;
 }
}
?>
