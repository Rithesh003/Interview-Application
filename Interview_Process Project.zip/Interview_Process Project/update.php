<?php
	include('dbconfig/config.php');
	$id=$_GET['id'];
 
	$FirstName=$_POST['FirstName'];
	$LastName=$_POST['LastName'];
 
	mysqli_query($con,"UPDATE user1 SET FirstName='$FirstName', LastName='$LastName' WHERE id='$id'");
	header('location:dash1.php');
?>  