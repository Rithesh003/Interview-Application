<?php
    // Check if user has requested to get detail
    if (isset($_POST["get_data"]))
    {
        // Get the ID of customer user has selected
        $id = $_POST["id"];

        require_once('dbconfig/config.php');

        // Getting specific customer's detail
        $sql = "SELECT * FROM user1 WHERE id='$id'";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_object($result);

        // Important to echo the record in JSON format
        echo json_encode($row);

        // Important to stop further executing the script on AJAX by following line
        exit();
    }
?>
 <form action="dash1.php" method="post">
			<div class="inner_container">
				<button style='color:black;border:round' class="btn btn-primary" type="submit">back</button>	
			</div>
		</form>
<?php
        require_once('dbconfig/config.php');
    $sql = "SELECT * FROM user1";
    $result = mysqli_query($con, $sql);
?>

<!-- Include bootstrap & jQuery -->
<link rel="stylesheet" href="bootstrap1.css" />
<script src="jquery-3.3.1.min.js"></script>
<script src="bootstrap.js"></script>
<div class="container">

    <table class="table">
        <tr>
            
            <th>Name</th>
			<th>Email</th>
            <th>Phone</th>
			<th>Degree</th>
			<th>Pass Out Year</th>
            <th>Actions</th>
        </tr>
        <?php while ($row = mysqli_fetch_object($result)) { ?>
            <tr>
                
                <td><?php echo $row->FirstName;?></td>
				<td><?php echo $row->email;?></td>
                <td><?php echo $row->MobileNumber; ?></td>
				<td><?php echo $row->degree; ?></td>
				<td><?php echo $row->passoutyear; ?></td>
                <!--Button to display details -->
               
        <td>
            <button class = "btn btn-primary" onclick="loadData(this.getAttribute('data-id'));" data-id="<?php echo $row->id; ?>">
                Details
            </button>
           
			<!-- <button class = "btn btn-info" onClick="document.location.href='editform.php'">
                Edit
            </button>
			<button class = "btn btn-danger" onClick="document.location.href='delete.php'" >
                Delete
            </button> -->
        </td>
            </tr>
        <?php } ?>

        <!-- Display dynamic records from database -->
        
    </table>
</div>

<script>
    function loadData(id) {
        console.log(id);
        $.ajax({
            url: "View.php",
            method: "POST",
            data: {get_data: 1, id: id},
            success: function (response) {
                response = JSON.parse(response);
                console.log(response);
                var html = "";
                html += "<div class='row'>";
                    html += "<div class='col-md-6'><strong>Details</strong></div>";
                    html += "<div class='col-md-7'> Name: "+ response.FirstName +" "+ response.LastName+ "</div>";
                    html += "<div class='col-md-8'> Email: "+ response.email + "</div>";
                    html += "<div class='col-md-9'>Location: "+ response.location + "</div>";
                    html += "<div class='col-md-8'>Mobile Number: "+ response.MobileNumber + "</div>";
                    html += "<div class='col-md-9'>Gender: "+ response.Gender+ "</div>";
                    html += "<div class='col-md-8'>Degree: "+ response.degree+ "</div>";
                    html += "<div class='col-md-9'>Department: "+ response.department+ "</div>";
                    html += "<div class='col-md-8'>Passout Year: "+ response.passoutyear+ "</div>";
                    html += "<div class='col-md-9'>Languages: "+ response.languages+ "</div>";
                html += "</div>";
                $("#modal-body").html(html);

                $("#myModal").modal();
            }
        });
    }
</script>
<!-- Modal -->
<div class = "modal fade" id = "myModal" tabindex = "-1" role = "dialog" aria-hidden = "true">
   
   <div class = "modal-dialog">
      <div class = "modal-content">
         
         <div class = "modal-header">
            <h4 class = "modal-title">
               Customer Detail
            </h4>

            <button type = "button" class = "close" data-dismiss = "modal" aria-hidden = "true">
               ×
            </button>
         </div>
         
         <div id = "modal-body">
            Press ESC button to exit.
         </div>
         
         <div class = "modal-footer">
            <button type = "button" class = "btn btn-default" data-dismiss = "modal">
               OK
            </button>
         </div>
         
      </div><!-- /.modal-content -->
   </div><!-- /.modal-dialog -->
   
</div><!-- /.modal -->
<!-- Modal -->
<div class = "modal fade" id = "myModal" tabindex = "-1" role = "dialog" aria-hidden = "true">
    
   <div class = "modal-dialog">
      <div class = "modal-content">
          
         <div class = "modal-header">
            <h4 class = "modal-title">
               Customer Detail
            </h4>
 
            <button type = "button" class = "close" data-dismiss = "modal" aria-hidden = "true">
               ×
            </button>
         </div>
          
         <div id = "modal-body">
            Press ESC button to exit.
         </div>
          
         <div class = "modal-footer">
            <button type = "button" class = "btn btn-default" data-dismiss = "modal">
               OK
            </button>
         </div>
          
      </div><!-- /.modal-content -->
   </div><!-- /.modal-dialog -->
    
</div><!-- /.modal -->