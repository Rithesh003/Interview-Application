<?php
	session_start();
	require_once('dbconfig/config.php');
	//phpinfo();
?>
<!DOCTYPE html>
<html>
<head>
<title>Sign Up Page</title>
<!-- <link rel="stylesheet" href="css/style.css"> -->

</head>
<!-- <body style="background-color:#bdc3c7"> -->
<?php include ('nav.php'); ?>
	<center><h2>Sign Up Form</h2></center>
		<form action="register.php" method="post">
			<link href="css/form.css" rel="stylesheet">
			<div class="container">
				<label><b>First Name</b></label><br>
				<input type="text" placeholder="Enter FirstName" name="FirstName" required><br>
				<label><b>Last Name</b></label><br>
				<input type="text" placeholder="Enter LastName" name="LastName" required><br>
				<label><b>Email</b></label><br>
                <input type="text" placeholder="Enter Email" name="email" id="email" required><br>
				<label><b>Current Location</b></label><br>
                <input type="text" placeholder="Enter your current location" name="location" id="location" required><br>
                <label><b>Mobile Number</b></label><br>
                <input type="text" placeholder="Enter your 10 digit MobileNumber" name="MobileNumber" id="MobileNumber" required><br>
				<label><b>Gender</b></label><br>
                <input type="radio" id="Male" name="Gender" value="Male" required="required">
                <label for ="Male">Male</label><br>
                <input type="radio" id="Female" name="Gender" value="Female">
                <label for="Female">Female</label><br>
			 <div class="select">
                <label for="degree"> <b>Degree</b></label><br><br>
                <select class="select" id="degree"  name="degree"  required>
                <option value="B.E">B.E</option>
                <option value="B.Tech">B.Tech</option>
                <option value="M.E">M.E</option>
                <option value="M.Tech">M.Tech</option>
                <option value="MCA">MCA</option>
                <option value="B.Sc">B.Sc</option>
                <option value="BCA">BCA</option>
                <option value="Diploma">Diploma</option>    
                </select>
             </div>
			<div class="select">
       <br> <label for="department"><b>Department</b></label><br><br>
  
          <select id="department" name="department" class="select" required>
          <option value="CSE">ComputerScience and Engineering</option>
          <option value="ECE">Electronics and Communication Engineering</option>
          <option value="Mech">Mechanical Engineering</option>
          <option value="EEE">Electrical and Electronical Engineering</option>
          <option value="CS">ComputerScience</option>
          <option value="IT">Information and Technology</option>
          <option value="CA">Computer Applications</option>
      </select>
      </div>
      <div class="select">
        <br><label for="PassoutYear"><b>PassoutYear</b></label><br><br>
        <select name="passoutyear" class="form-control" id="dropdownYear"
	        style="width: 120px;" required>
        </select>
       <script>
            var i, currentYear, startYear, endYear, newOption, dropdownYear;
            dropdownYear = document.getElementById("dropdownYear");
            currentYear = (new Date()).getFullYear();
            startYear = currentYear - 5;
            endYear = currentYear;

            for (i=startYear;i<=endYear;i++) {
                newOption = document.createElement("option");
                newOption.value = i;
                newOption.label = i;
                dropdownYear.appendChild(newOption);
            }
        </script>
     <script type="text/javascript">
        function EnableDisableCheckBox() {
            var chkYes = document.getElementById("Yes");
            var fieldset = document.getElementById("checkbox");
            fieldset.disabled = chkYes.checked ? false : true;
            if (!fieldset.disabled) {
                fieldset.focus();
            }
        }
       </script>
      <div class="fieldset">
       <br><label for="skills"><b>Programming Skills</b></label><br><br>
        <input type="radio" id="Yes" name="skills" value="Yes" onclick="EnableDisableCheckBox()" required="required">
        <label for="Yes">Yes</label>
        <input type="radio" id="No" name="skills" value="No" onclick="EnableDisableCheckBox()">
        <label for="No">No</label><br><br>

        <br> <label for="languages"><b>Programming Languages</b></label><br><br>
        <fieldset  id="checkbox" disabled="disabled">
        <input type="checkbox" id="C++" name="languages[]" value="C++">
        <label for="C++"> C++</label><br>
        <input type="checkbox" id="Java"  name="languages[]" value="Java">
        <label for="Java"> Java</label><br>
        <input type="checkbox" id="Python" name="languages[]" value="Python">
        <label for="Python"> Python</label><br>
        <input type="checkbox" id="WebDesigningStack" name="languages[]"  value="WebDesigningStack">
        <label for="WebDesigningStack">HTML,CSS,JS</label><br>
        <input type="checkbox" id="Others" name="languages[]"  value="Others">
        <label for="Others">Others</label><br>
       
        </fieldset>
      </div>
      <br>
      </div>
				<button name="register" class="registerbtn" type="submit">Sign Up</button><br>
				
				<a href="index.php"><button type="button" class="back_btn"><< Back to Login</button></a>
			</div>
		</form>
		
		<?php
			if(isset($_POST['register']))
			{
                @$id=$_POST['id'];
				@$FirstName=$_POST['FirstName'];
				@$LastName=$_POST['LastName'];
				@$email=$_POST['email'];
				@$location=$_POST['location'];
				@$MobileNumber=$_POST['MobileNumber'];
				@$Gender=$_POST['Gender'];
				@$degree=$_POST['degree'];
				@$department=$_POST['department'];
				@$passoutyear=$_POST['passoutyear'];
				@$skills=$_POST['skills'];
				// @$languages=$_POST["languages"];
            //    if(!empty($_POST['languages'])){
            //           foreach($_POST['languages'] as $checked){
            //             echo $checked . '<br>';
            //           }
            //         } else {
            //           echo '<div class="error">Checkbox is not selected!</div>';
            //         }
                
				if($FirstName==$LastName)
				{
					echo '<script type="text/javascript">alert("FisrtName and LastName Same Please Check!")</script>';
				}
				else
				{
					// $query = "select * from user1";
					// echo $query;
				    $query = "SELECT * FROM user1 WHERE FirstName ='$FirstName'";
					$query_run=mysqli_query($con,$query);
				// echo mysql_num_rows($query_run);
					if($query !== $FirstName)
					{
						if($query>0)
						{ $checkbox1=$_POST['languages'];  
                            $chk="";  
                            foreach($checkbox1 as $chk1)  
                               {  
                                  $chk .= $chk1.",";  
                               }  
							$query = "INSERT INTO user1 VALUES('$id','$FirstName','$LastName','$email','$location','$MobileNumber','$Gender','$degree','$department','$passoutyear','$skills','$chk')";
							$query_run = mysqli_query($con,$query);
							echo '<script type="text/javascript">alert("User Registered.. Welcome")</script>';
							
						}
						else
			            {
							echo '<script type="text/javascript">alert("User Exists")</script>';
						}
					}
					else
					{
						echo '<script type="text/javascript">alert("DB error")</script>';
					}
				}
				}
			
			
			
		?>
	</div>
</body>
</html>