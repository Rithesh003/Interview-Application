
<style>
</style>
<nav id="sidebar" class='mx-lt-5 bg-dark' >
		
		<div class="sidebar-list">

				<a href="home1.php" class="nav-item nav-home" style="font-size:22px"><span class='icon-field' style="font-size:12px"><i class="fa fa-home" style="font-size:22px"></i></span> Home</a>
				<!-- <a href="" class="nav-item nav-applications"><span class='icon-field'><i class="fa fa-user-tie"></i></span> Applications</a>	 -->
				<a href="homepage.php" class="nav-item nav-vacancy" style="font-size:22px"><span class='icon-field'><i class="fa fa-list-alt"style="font-size:22px"></i></span>Candidate List</a>	
				<!-- <a href=".php?page=recruitment_status" class="nav-item nav-recruitment_status"><span class='icon-field'><i class="fa fa-th-list"></i></span> Status Category</a>		 -->
				<?php if($_SESSION['login_type'] == 1): ?>
				<!-- <a href="index.php?page=users" class="nav-item nav-users"><span class='icon-field'><i class="fa fa-users"></i></span> Users</a>
				<a href="index.php?page=site_settings" class="nav-item nav-site_settings"><span class='icon-field'><i class="fa fa-cogs"></i></span> Settings</a> -->
				
			<?php endif; ?>
		</div>

</nav>
<script>
	$('.nav-<?php echo isset($_GET['page']) ? $_GET['page'] : '' ?>').addClass('active')
</script>
