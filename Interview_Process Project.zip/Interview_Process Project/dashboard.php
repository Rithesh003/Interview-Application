<?php
require_once('dbconfig/config.php');    
?>
	<link href="css/style.css" rel="stylesheet">
    <link href="css/font-awesome.css" rel="stylesheet">
	<link href="css/bootstrap.css" rel="stylesheet" />
	<style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
	<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="dash1.php">Candidate List</a>
  <a href="dashboard.php">Dashboard</a>
  <a href="register.php">Register</a>
  <a href="index.php">Logout</a>
</div>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;Menu</span>
	<div class="content-wrapper">
<div class="container">
<div class="row pad-botm">
<div class="col-md-12">
<form action="index.php" method="post">
			<div class="inner_container">
				<button style='color:black;border:round' class="btn btn-submit" type="submit" >back</button>	
			</div>
<!-- </form>
<form action="register.php" method="post">
<button type="submit" name="login" class="btn btn-info">Register </button>
</form> -->
</div>
</div>
</div>
		 		
		<div class="col-md-12">
                <h4 class="header-line">ADMIN DASHBOARD</h4>
                
        </div>
		    <div class="row">
                    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="alert alert-info back-widget-set text-center">
						<div class="stat-panel-title text-uppercase" style="color:Black">Total Users</div>
							<?php 
									$query = "SELECT COUNT(id) FROM user1 "; 
									$result = mysqli_query($con,$query);
									while($row = mysqli_fetch_array($result)){
                                     echo $row['COUNT(id)'];
	                                 echo "<br />";
                                     }?>
									
									
                        </div>
                    </div>      
					<div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="alert alert-success back-widget-set text-center">
						<div class="stat-panel-title text-uppercase"style="color:black">No Candidates of both genders</div>
							<?php 
									$query = "SELECT Gender, COUNT(FirstName) FROM user1 GROUP BY Gender"; 
									$result = mysqli_query($con,$query);
									while($row = mysqli_fetch_array($result)){
                                     echo $row['Gender'] ." - ".$row['COUNT(FirstName)'];
	                                 echo "<br />";
                                     }?>
                                    
                        </div>
                    </div>
				    <div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="alert alert-info back-widget-set text-center">
						<div class="stat-panel-title text-uppercase"style="color:black">No of pass outs in the year</div>
					            <?php
									$query = "SELECT passoutyear, COUNT(FirstName) FROM user1 GROUP BY passoutyear"; 
									$result = mysqli_query($con,$query);
									while($row = mysqli_fetch_array($result)){
                                     echo " ".$row['passoutyear']." - ".$row['COUNT(FirstName)'];
	                                 echo "<br />";
                                     }
									?>
                                   
                        </div>
                    </div>	
					<div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="alert alert-success back-widget-set text-center">
						<div class="stat-panel-title text-uppercase"style="color:black">No of candidates from the location</div>
							        <?php 
									$query = "SELECT location, COUNT(FirstName) FROM user1 GROUP BY location"; 
									$result = mysqli_query($con,$query);
									// echo " <br>";
									while($row = mysqli_fetch_array($result)){
										echo $row['location']." - ".$row['COUNT(FirstName)'];
	                                 echo "<br />";
                                     }?>
                                     
                        </div>
					</div>
					<div class="col-md-4 col-sm-6 col-xs-12">
                        <div class="alert alert-info back-widget-set text-center">
						<div class="stat-panel-title text-uppercase" style="color:black">Count of Candidates in Degree</div>
                            
							        <?php 
									$query = "SELECT degree,COUNT(FirstName)FROM user1 GROUP BY degree"; 
									$result = mysqli_query($con,$query);
									while($row = mysqli_fetch_array($result)){
                                     echo $row['degree']." - ".$row['COUNT(FirstName)'];
	                                 echo "<br />";
                                     }?>

                                    
                        </div>
					</div>
					   <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="alert alert-success back-widget-set text-center">
							<div class="stat-panel-title text-uppercase" style="color:black">Count of Candidates in Department</div> 
					                <?php 
									$query = "SELECT COUNT(FirstName),department FROM user1 GROUP BY department";
									$result = mysqli_query($con,$query);
									while($row = mysqli_fetch_array($result)){
										echo $row['department']." - ".$row['COUNT(FirstName)'];
	                                 echo "<br />";
                                     }?>
							
								     
                             </div>
				        </div>

					   <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="alert alert-success back-widget-set text-center">
							<div class="stat-panel-title text-uppercase" style="color:black">Programming skills/Languages</div> 
					                <?php 
									$query = "SELECT FirstName,languages FROM user1 "; 
									$result = mysqli_query($con,$query);
									while($row = mysqli_fetch_array($result)){
										echo $row['FirstName'] ." - ".$row['languages'];
	                                 echo "<br />";
                                     }?>
							          
                            </div>
					    </div>

				        
			</div>
	</div>		
</div>
<script>
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}
</script>