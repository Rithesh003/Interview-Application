<?php
require('dbconfig/config.php');
$id=$_REQUEST['id'];
$query = "DELETE FROM user1 WHERE id=$id"; 
$result = mysqli_query($con,$query);
header("Location:dash1.php"); 
?>