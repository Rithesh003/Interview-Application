<?php
require_once('dbconfig/config.php');
$sql = "SELECT * FROM user1";  
$result = mysqli_query($con, $sql);
?>
<html>  
 <head>  
 <style>
body {
  font-family: "Lato", sans-serif;
}

.sidenav {
  height: 100%;
  width: 0;
  position: fixed;
  z-index: 1;
  top: 0;
  left: 0;
  background-color: #111;
  overflow-x: hidden;
  transition: 0.5s;
  padding-top: 60px;
}

.sidenav a {
  padding: 8px 8px 8px 32px;
  text-decoration: none;
  font-size: 25px;
  color: #818181;
  display: block;
  transition: 0.3s;
}

.sidenav a:hover {
  color: #f1f1f1;
}

.sidenav .closebtn {
  position: absolute;
  top: 0;
  right: 25px;
  font-size: 36px;
  margin-left: 50px;
}

@media screen and (max-height: 450px) {
  .sidenav {padding-top: 15px;}
  .sidenav a {font-size: 18px;}
}
</style>
	<div id="mySidenav" class="sidenav">
  <a href="javascript:void(0)" class="closebtn" onclick="closeNav()">&times;</a>
  <a href="dashboard.php">Dashboard</a>
  <a href="dash1.php">Candidate List</a>
  
  <a href="register.php">Register</a>
  <a href="export.php">Export List</a>
  <a href="index.php">Logout</a>
</div>
<span style="font-size:30px;cursor:pointer" onclick="openNav()">&#9776;Menu</span>
  <title>Candidate details from the Registration form</title>  
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />  
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>  
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>  
 </head>  
 <body>  
  <div class="container">  
   <br />  
   <br />  
   <br />  
   <form action="dashboard.php" method="post">
			<div class="inner_container">
				<button style='color:black;border:round;font-size: 16px;' class="btn btn-primary" type="submit">back</button>	
			</div>
		</form>
   <!-- <form action="dashboard.php" method="post">
			<div class="inner_container">
				<button style='color:black;font-size:20px;border:round' class="btn btn-danger" type="submit">Dashboard</button>	
			</div>
		</form> 
   <form method="post" action="export.php">
     <input type="submit" name="export" style='color:black;font-size:20px;border:round' class="btn btn-success" value="Export" />
    </form> -->
   
				<div class="table-responsive">  
    <h2 align="center">Candidate details from the Registration form</h2><br /> 


    <br />
   </div>  
  </div>
			
			<!-- Table Panel -->
		</div>
	</div>	

</div>
<!-- Modal -->
<div class = "modal fade" id = "myModal" tabindex = "-1" role = "dialog" aria-hidden = "true">
    
   <div class = "modal-dialog">
      <div class = "modal-content">
          
         <div class = "modal-header">
            <h4 class = "modal-title">
               Customer Detail
            </h4>
 
            <button type = "button" class = "close" data-dismiss = "modal" aria-hidden = "true">
               ×
            </button>
         </div>
          
         <div id = "modal-body">
            Press ESC button to exit.
         </div>
          
         <div class = "modal-footer">
            <button type = "button" class = "btn btn-default" data-dismiss = "modal">
               OK
            </button>
         </div>
          
      </div><!-- /.modal-content -->
   </div><!-- /.modal-dialog -->
    
</div><!-- /.modal -->
<style>
	
	td{
		vertical-align: middle !important;
	}
	td p{
		margin: unset
	}
	img{
		max-width:100px;
		max-height: :150px;
	}
</style>
<script>
/* Set the width of the side navigation to 250px and the left margin of the page content to 250px */
function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
  document.getElementById("main").style.marginLeft = "250px";
}

/* Set the width of the side navigation to 0 and the left margin of the page content to 0 */
function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
  document.getElementById("main").style.marginLeft = "0";
}
</script>
<?php
    // Check if user has requested to get detail
    if (isset($_POST["get_data"]))
    {
        // Get the ID of customer user has selected
        $id = $_POST["id"];

        require_once('dbconfig/config.php');

        // Getting specific customer's detail
        $sql = "SELECT * FROM user1 WHERE id='$id'";
        $result = mysqli_query($con, $sql);
        $row = mysqli_fetch_object($result);

        // Important to echo the record in JSON format
        echo json_encode($row);

        // Important to stop further executing the script on AJAX by following line
        exit();
    }
?>

<?php
        require_once('dbconfig/config.php');
    $sql = "SELECT * FROM user1";
    $result = mysqli_query($con, $sql);
?>

<!-- Include bootstrap & jQuery -->
<link rel="stylesheet" href="bootstrap1.css" />
<script src="jquery-3.3.1.min.js"></script>
<script src="bootstrap.js"></script>

<!-- Creating table heading -->

<div class="container">

    <table class="table">
        <tr>
            <th>ID</th>
            <th>Name</th>
			<th>Email</th>
            <th>Phone</th>
			<th>Degree</th>
			<th>Pass Out Year</th>
            <th>Actions</th>
        </tr>
        <?php
					include('dbconfig/config.php');
					$query=mysqli_query($con,"select * from user1");
					while($row=mysqli_fetch_array($query)){
						?>
            <tr>
                <td><?php echo $row['id'] ?></td>
                <td><?php echo $row['FirstName']?></td>
				<td><?php echo $row['email']?></td>
                <td><?php echo $row['MobileNumber'] ?></td>
				<td><?php echo $row['degree'] ?></td>
				<td><?php echo $row['passoutyear']?></td>
              <td>
              <a href="details.php?id=<?php echo $row['id']; ?>">Details</a>
                <a href="editform.php?id=<?php echo $row['id']; ?>">Edit</a>
								<a href="delete.php?id=<?php echo $row['id']; ?>">Delete</a>
              </td>
								
							</td>
						</tr>
						<?php
					}
				?> 

        <!-- Display dynamic records from database -->
        
    </table>
</div>



