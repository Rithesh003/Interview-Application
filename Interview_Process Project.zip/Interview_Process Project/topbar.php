<nav class="navbar navbar-light fixed-top bg-primary" style="padding:0;">
  <div class="container-fluid mt-5 mb-2">
  	<div class="col-lg-09">
      <div class="col-md-6 text-white">
        <large><b>Interview Management System</b></large>
      </div>
	  	
    </div>
  </div>
  <a href="index.php" style="color:white"><i style="font-size:24px" class="fa">&#xf011; Logout</i></a>
  <div class="col-md-11 float-right text-white">
  </div>
</nav>