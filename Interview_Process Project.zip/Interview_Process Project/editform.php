<?php
	include('dbconfig/config.php');
	$id=$_GET['id'];
	$query=mysqli_query($con,"SELECT * FROM user1 WHERE id='$id'");
	$row=mysqli_fetch_array($query);
?>
<!DOCTYPE html>
<html>
<head>
<title>Edit Details</title>
</head>
<body>
	<h2>Edit Name</h2>
	<form method="POST" action="update.php?id=<?php echo $row['id']; ?>">
		<label>Firstname:</label><input type="text" value="<?php echo $row['FirstName']; ?>" name="FirstName">
		<label>Lastname:</label><input type="text" value="<?php echo $row['LastName']; ?>" name="LastName">
		<input type="submit" name="submit">
		<a href="dash1.php">Back</a>
        
	</form>
</body>
</html>
