<nav class="navbar navbar-inverse" style="width: 81% !important; margin: auto;">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="">Interview Application</a>
    </div>
    <ul class="nav navbar-nav">
      <li class="menu_active"><a href="index.php">Home</a></li>
      <li class="menu_active"><a href="register.php">Register</a></li>
      
      <!-- <li><a href="addQuestion.php">Add New Question</a></li> -->
      <!-- <li><a href="viewCandidate.php">View Candidates</a></li> -->
      <!-- <li><a href="viewQuestions.php">View Questions</a></li> -->
    </ul>
  </div>
</nav>
